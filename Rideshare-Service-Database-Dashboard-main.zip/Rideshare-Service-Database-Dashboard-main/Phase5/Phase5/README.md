How to run:
1. This project is made on Visual Studio Code using Node JS, HTML and JavaScript
2. Connect to the VPN.
3. From terminal, call node .\index.js
4. Goto http://localhost:3000/ in browser
5. in Navbar we have the follwing options:
    a. View Passengers, View Drivers and View Bookings show all the contents of these tables.
    b. Search, Insert and Delete passenger options are given to search/insert/delete a particular passenger record.
    c. Modify Booking - Modifies the fare amount of a given BookingID for the provided BID value. 
6. Three dynamic SQL queries are demonstrated as Business Goal 1, Business Goal 2,  Business Goal 3  which includes
   aggregates, HAVING clause, GROUP BY , ORDER BY and ROLLUP clauses.